from com.mosh.work_package.package.second_sub import second_module


def first_md():
    print("first module..")


second_module.second_md()
