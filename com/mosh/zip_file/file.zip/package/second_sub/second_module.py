def second_md():
    print("second module..")